package it.unige.blackbird.newsreader;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;

public class ChooseActivity extends Activity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_site);

        RadioButton SportsButton = (RadioButton) findViewById(R.id.SportsButton);
        RadioButton ScienceButton = (RadioButton) findViewById(R.id.ScienceButton);
        RadioButton HealthButton = (RadioButton) findViewById(R.id.HealthButton);

        SportsButton.setOnClickListener(this);
        HealthButton.setOnClickListener(this);
        HealthButton.setOnClickListener(this);
    }

    public void onClick(View v){
        switch(v.getId()) {
            case R.id.SportsButton:
                FileIO.URL_STRING = "https://rss.nytimes.com/services/xml/rss/nyt/Sports.xml";
            case R.id.ScienceButton:
                FileIO.URL_STRING = "https://rss.nytimes.com/services/xml/rss/nyt/Science.xml";
            case R.id.HealthButton:
                FileIO.URL_STRING = "https://rss.nytimes.com/services/xml/rss/nyt/Health.xml";
        }
    }
}